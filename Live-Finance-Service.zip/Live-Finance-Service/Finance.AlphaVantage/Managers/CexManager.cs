﻿using Finance.Cex.Models;
using Finance.Cex.Repositories;
using Finance.Cex.Utilities;
using Finance.Cex.Utilities.EventLogger;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Finance.Cex.Managers
{
    public class CexManager : ICexManager
    {
        private readonly HttpClient _httpClient;
        private readonly IOptions<CexSettings> _settings;
        private readonly IRequestLogger _requestLogger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ICexRepository _cexRepository;
        private ClientWebSocket _webSocket;
        private CancellationTokenSource _cancellationTokenSource;
        private readonly SemaphoreSlim _lock = new SemaphoreSlim(1);
        private string _lastReceivedMessage;

        public CexManager(HttpClient httpClient, IOptions<CexSettings> settings, IRequestLogger requestLogger, IHttpContextAccessor httpContextAccessor, ICexRepository cexRepository)
        {
            _httpClient = httpClient;
            _settings = settings;
            _requestLogger = requestLogger;
            _httpContextAccessor = httpContextAccessor;
            _cexRepository = cexRepository;
        }

        public async Task<GlobalResponse<Instruments>> RetrieveInstrumentsAsync()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }

                // Define the data to be sent
                var cryptoPairs = new CexRequest
                {
                    pairs = new List<string> { "BTC-USDT", "AVAX-USDT", "ADA-USDT" }
                };

                // Serialize the object to JSON
                var json = JsonConvert.SerializeObject(cryptoPairs);

                // Create the StringContent object with the JSON payload
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Send the POST request asynchronously
                var response = await _httpClient.PostAsync(_settings.Value.ticker_url, content);
                response.EnsureSuccessStatusCode(); // Throw if not a success code.

                // Read the response content asynchronously
                var responseContent = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to Instruments object
                var cexResponse = JsonConvert.DeserializeObject<Instruments>(responseContent);

                return new GlobalResponse<Instruments>() { result = cexResponse };
            }
            catch (HttpRequestException ex)
            {
                Log.Error("HTTP request failed. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveInstrumentsAsync), ex.ToString());
                throw;
            }
            catch (JsonException ex)
            {
                Log.Error("Failed to deserialize JSON response. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveInstrumentsAsync), ex.ToString());
                throw;
            }
            catch (Exception ex)
            {
                Log.Error("An exception occurred. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveInstrumentsAsync), ex.ToString());
                throw;
            }
        }


        public async Task<GlobalResponse<InstrumentDetails>> RetrieveCurrentPriceAsync(string pair)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }

                var url = $"{_settings.Value.order_book_url}?pair={pair}";
                var response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode(); // Throw if not a success code.

                var responseContent = await response.Content.ReadAsStringAsync();

                InstrumentDetails cexResponse = null;
                try
                {
                    cexResponse = JsonConvert.DeserializeObject<InstrumentDetails>(responseContent);
                }
                catch (JsonException ex)
                {
                    Log.Error("Failed to deserialize JSON response. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveCurrentPriceAsync), ex.ToString());
                    throw;
                }

                return new GlobalResponse<InstrumentDetails>() { result = cexResponse };
            }
            catch (HttpRequestException ex)
            {
                Log.Error("HTTP request failed. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveCurrentPriceAsync), ex.ToString());
                throw;
            }
            catch (Exception ex)
            {
                Log.Error("An exception occurred. Method: {MethodName}, Error: {ErrorMessage}", nameof(RetrieveCurrentPriceAsync), ex.ToString());
                throw;
            }
        }

        public async Task ConnectAsync(Uri uri)
        {
            _webSocket = new ClientWebSocket();
            _cancellationTokenSource = new CancellationTokenSource();
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }
                await _webSocket.ConnectAsync(uri, _cancellationTokenSource.Token);
                _requestLogger.LogWebSocketMessage("websocket connected!");
                _ = Task.Run(ReceiveMessages);
            }
            catch (Exception ex)
            {
                _requestLogger.LogWebSocketMessage(ex.Message);
                throw;
            }
        }

        public async Task<string> SendMessageAsync(string message)
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext != null)
            {
                _requestLogger.LogEventRequest(httpContext);
            }
            if (_webSocket == null)
            {
                _requestLogger.LogWebSocketMessage("Please connect to the websocket first by hitting the ConnectWebSocket Endpoint.");
                throw new InvalidOperationException("Please connect to the websocket first by hitting the ConnectWebSocket Endpoint.");
            }
            if (_webSocket.State != WebSocketState.Open)
            {
                _requestLogger.LogWebSocketMessage("WebSocket is not open.");
                throw new InvalidOperationException("WebSocket is not open.");
            }

            try
            {
                byte[] bytes = Encoding.UTF8.GetBytes(message);
                await _webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, _cancellationTokenSource.Token);
                await Task.Delay(1000);
                await _lock.WaitAsync();
                try
                {
                    return _lastReceivedMessage;
                }
                finally
                {
                    _lock.Release();
                }
            }
            catch (Exception ex)
            {
                _requestLogger.LogWebSocketMessage(ex.Message);
                throw;
            }
        }

        private async Task ReceiveMessages()
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext != null)
            {
                _requestLogger.LogEventRequest(httpContext);
            }
            var buffer = new byte[1024 * 4];
            try
            {
                while (_webSocket.State == WebSocketState.Open)
                {
                    var result = await _webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), _cancellationTokenSource.Token);

                    if (result.MessageType == WebSocketMessageType.Text)
                    {
                        string message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                        _requestLogger.LogWebSocketMessage("Received message: " + message);
                        await _lock.WaitAsync();
                        try
                        {
                            _lastReceivedMessage = message;


                            // Here we can call a method to broadcast message to all subscribed clients
                        }
                        finally
                        {
                            _lock.Release();
                        }
                    }
                    else if (result.MessageType == WebSocketMessageType.Close)
                    {
                        _requestLogger.LogWebSocketMessage("WebSocket connection closed.");
                        break;
                    }
                }
            }
            catch (WebSocketException wsex) when (wsex.WebSocketErrorCode == WebSocketError.ConnectionClosedPrematurely)
            {
                _requestLogger.LogWebSocketMessage("WebSocket connection closed prematurely.");
            }
            catch (Exception ex)
            {
                _requestLogger.LogWebSocketMessage("Error receiving message: " + ex.Message);
            }
            finally
            {
                await DisconnectAsync();
            }
        }

        // To efficiently manage 1,000+ WebSocket subscribers, we can:
        // - Use a ConcurrentDictionary to handle client connections safely across multiple threads.
        // - Use async/await for non-blocking operations.
        // - Optimize the broadcast logic to reduce delays, for example by sending messages in parallel.

        public async Task DisconnectAsync()
        {
            if (_webSocket.State == WebSocketState.Open)
            {
                _cancellationTokenSource.Cancel();
                await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "WebSocket closed by client", CancellationToken.None);
                _webSocket.Dispose();
            }
        }
    }
}
