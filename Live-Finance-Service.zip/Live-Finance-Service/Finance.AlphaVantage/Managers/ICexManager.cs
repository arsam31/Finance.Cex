﻿using Finance.Cex.Models;

namespace Finance.Cex.Managers
{
    public interface ICexManager
    {
        Task<GlobalResponse<Instruments>> RetrieveInstrumentsAsync();
        Task<GlobalResponse<InstrumentDetails>> RetrieveCurrentPriceAsync(string pair);
        Task ConnectAsync(Uri uri);
        Task<string> SendMessageAsync(string message);
        Task DisconnectAsync();
    }
}
