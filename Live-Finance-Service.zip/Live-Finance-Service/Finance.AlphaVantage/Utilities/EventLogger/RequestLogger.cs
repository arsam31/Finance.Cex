﻿using Finance.Cex.Models;
using Newtonsoft.Json;
using Serilog;
using System.Security.Claims;

namespace Finance.Cex.Utilities.EventLogger
{
    public class RequestLogger : IRequestLogger
    {
        public void LogEventRequest(HttpContext httpContext)
        {
            var ipAddress = httpContext?.Connection.RemoteIpAddress;
            var dateOfRequestGenerated = DateTime.Now;
            var requestMethod = httpContext?.Request.Method;
            var requestPath = httpContext?.Request.Path;
            var userAgent = httpContext?.Request.Headers.UserAgent;
            Log.Information("Request is: Controller {ControllerName} called with IP {IpAddress} at {DateOfRequest}. Request details: Method: {RequestMethod}, Path: {RequestPath}, User Agent: {UserAgent}.",
                "AuthController", ipAddress, dateOfRequestGenerated, requestMethod, requestPath, userAgent);
        }

        public void LogWebSocketMessage(string message)
        {
            Log.Information("Web socket response is:", message);
        }

        public void LogEventResponse<T>(GlobalResponse<T> response)
        {
            var serializedResponse = JsonConvert.SerializeObject(response);
            Log.Information("Response Object is: {SerializedResponse}", serializedResponse);
        }

        public void LogExceptionDetails(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            var logValues = new object[propertyValues.Length + 1];
            logValues[0] = exception;
            Array.Copy(propertyValues, 0, logValues, 1, propertyValues.Length);
            Log.Information("Exception: {Exception}. " + messageTemplate, logValues);
        }
    }
}
