﻿using Finance.Cex.Models;

namespace Finance.Cex.Utilities.EventLogger
{
    public interface IRequestLogger
    {
        void LogEventRequest(HttpContext httpContext);
        void LogWebSocketMessage(string message);
        void LogEventResponse<T>(GlobalResponse<T> response);
        void LogExceptionDetails(Exception exception, string messageTemplate, params object[] propertyValues);
    }
}
