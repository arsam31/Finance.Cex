﻿using System.Text.Json.Serialization;

namespace Finance.Cex.Models
{
    public class CexRequest
    {
        public List<string> pairs { get; set; }
    }
}
