﻿using System.Xml.Linq;

namespace Finance.Cex.Models
{

    public class CexData
    {
        public long timestamp { get; set; }
        public string currency1 { get; set; }
        public string currency2 { get; set; }
        public List<List<string>> bids { get; set; }
        public List<List<string>> asks { get; set; }
    }

    public class InstrumentDetails
    {
        public string ok { get; set; }
        public CexData data { get; set; }
    }
}
