﻿namespace Finance.Cex.Models
{
    public class GlobalResponse<T>
    {
        public T? result { get; set; }
    }
}
