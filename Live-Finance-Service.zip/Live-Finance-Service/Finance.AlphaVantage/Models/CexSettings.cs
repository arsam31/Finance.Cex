﻿namespace Finance.Cex.Models
{
    public class CexSettings
    {
        public string? ticker_url { get; set; }
        public string? order_book_url { get; set; }
    }
}
