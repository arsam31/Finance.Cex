﻿namespace Finance.Cex.Models
{
    public class OrderBookRequest
    {
        public string e { get; set; }
        public string oid { get; set; }
        public OrderBookData data { get; set; }
    }

    public class OrderBookData
    {
        public string pair { get; set; }
    }
}
