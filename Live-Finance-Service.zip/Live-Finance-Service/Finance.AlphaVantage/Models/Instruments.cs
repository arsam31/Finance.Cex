﻿namespace Finance.Cex.Models
{
    public class Instruments
    {
        public string Ok { get; set; }
        public Dictionary<string, CurrencyInfo> Data { get; set; }
    }

    public class CurrencyInfo
    {
        public string BestBid { get; set; }
        public string BestAsk { get; set; }
        public string BestBidChange { get; set; }
        public string BestBidChangePercentage { get; set; }
        public string BestAskChange { get; set; }
        public string BestAskChangePercentage { get; set; }
        public string Low { get; set; }
        public string High { get; set; }
        public string Volume30d { get; set; }
        public DateTime LastTradeDateISO { get; set; }
        public string Volume { get; set; }
        public string QuoteVolume { get; set; }
        public string LastTradeVolume { get; set; }
        public string VolumeUSD { get; set; }
        public string Last { get; set; }
        public string LastTradePrice { get; set; }
        public string PriceChange { get; set; }
        public string PriceChangePercentage { get; set; }
    }
}
