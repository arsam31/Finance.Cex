﻿
using Finance.Cex.Managers;
using Finance.Cex.Utilities.EventLogger;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Serilog;
using System.Net;
using Finance.Cex.Models;

namespace Finance.Cex.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CexController : Controller
    {

        private readonly ICexManager _cexManager;
        private readonly IRequestLogger _requestLogger;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CexController(ICexManager cexManager, IRequestLogger requestLogger, IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _cexManager = cexManager;
            _requestLogger = requestLogger;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("FetchAvailableInstruments")]
        public async Task<IActionResult> FetchAvailableInstruments()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }
                var result = await _cexManager.RetrieveInstrumentsAsync();
                _requestLogger.LogEventResponse(result);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error("An exception has occured. Details:: Method name: {MethodName}, Error message: {ErrorMessage}", nameof(FetchAvailableInstruments), ex.Message);
                throw;
            }
        }

        [HttpPost("FetchInstrumentPrice")]
        public async Task<IActionResult> FetchInstrumentPrice(string pair)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }
                var result = await _cexManager.RetrieveCurrentPriceAsync(pair);
                _requestLogger.LogEventResponse(result);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error("An exception has occured. Details:: Method name: {MethodName}, Error message: {ErrorMessage}", nameof(FetchInstrumentPrice), ex.Message);
                throw;
            }
        }

        [HttpGet("ConnectWebSocket")]
        public async Task<IActionResult> ConnectWebSocket()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }
                Uri uri = new Uri("wss://trade.cex.io/api/spot/ws-public");
                await _cexManager.ConnectAsync(uri);
                _requestLogger.LogWebSocketMessage("WebSocket connected.");
                return Ok("WebSocket connected.");
            }
            catch (Exception ex)
            {
                Log.Error("An exception has occured. Details:: Method name: {MethodName}, Error message: {ErrorMessage}", nameof(ConnectWebSocket), ex.Message);
                return BadRequest($"Error connecting to WebSocket: {ex.Message}");
            }
        }


        [HttpPost("SendOrderBookRequest")]
        public async Task<IActionResult> SendOrderBookRequest([FromBody] OrderBookRequest request)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    _requestLogger.LogEventRequest(httpContext);
                }
                if (request == null)
                {
                    return BadRequest("Request body cannot be empty.");
                }
                string message = Newtonsoft.Json.JsonConvert.SerializeObject(request);
                string response = await _cexManager.SendMessageAsync(message);
                var globalResponse = new GlobalResponse<string>
                {
                    result = response,
                };
                _requestLogger.LogEventResponse(globalResponse);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Log.Error("An exception has occured. Details:: Method name: {MethodName}, Error message: {ErrorMessage}", nameof(SendOrderBookRequest), ex.Message);
                return BadRequest($"Error sending order book request: {ex.Message}");
            }
        }
    }
}
