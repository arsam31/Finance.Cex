using Finance.Cex.Managers;
using Finance.Cex.Models;
using Finance.Cex.Repositories;
using Finance.Cex.Utilities.EventLogger;
using Finance.Cex.Utilities.ExceptionHandler;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog((context, configuration) =>
configuration.ReadFrom.Configuration(context.Configuration));
builder.Services.AddHttpContextAccessor();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddSingleton<ICexManager, CexManager>();
builder.Services.AddTransient<ICexRepository, CexRepository>();
builder.Services.AddTransient<IRequestLogger, RequestLogger>();

builder.Services.AddHttpClient();
builder.Services.AddProblemDetails();
builder.Services.Configure<CexSettings>(builder.Configuration.GetSection("CexKeys"));
var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseExceptionHandler();
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
