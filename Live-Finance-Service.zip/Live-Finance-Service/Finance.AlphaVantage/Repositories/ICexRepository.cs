﻿namespace Finance.Cex.Repositories
{
    public interface ICexRepository
    {
    }
}
