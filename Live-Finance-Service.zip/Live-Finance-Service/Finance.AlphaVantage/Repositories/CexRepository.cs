﻿namespace Finance.Cex.Repositories
{
    public class CexRepository : ICexRepository
    {
    }
}
